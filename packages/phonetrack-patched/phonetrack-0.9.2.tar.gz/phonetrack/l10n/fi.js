OC.L10N.register(
    "phonetrack",
    {
    "Show lines" : "Näytä rivit"
},
"nplurals=2; plural=(n != 1);");
