# Приложение PhoneTrack в Nextcloud

📱 PhoneTrack е приложение Nextcloud за проследяване и съхраняване на местоположения на мобилни устройства.

🗺 Той получава информация от приложения за регистриране на мобилни телефони и я показва динамично на карта.

🌍 Помогнете ни да преведем това приложение на [PhoneTrack Crowdin project](https://crowdin.com/project/phonetrack).

⚒ Вижте други начини за помощ в [contribution guidelines](https://gitlab.com/eneiluj/phonetrack-oc/blob/master/CONTRIBUTING.md).

Как да използваме PhoneTrack:

- Създайте проследяваща сесия.
- Give the logging link\* to the mobile devices. Choose the [logging method](https://gitlab.com/eneiluj/phonetrack-oc/wikis/userdoc#logging-methods) you prefer.
- Гледайте местоположението на устройствата на сесията в реално време (или не) в PhoneTrack или го споделяйте с обществени страници.

(\*) Don't forget to set the device name in the link (rather than in the logging app settings). Replace "yourname" with the desired device name.
Setting the device name in logging app settings only works with Owntracks, Traccar and OpenGTS.

На основната страница на PhoneTrack, докато гледате сесия, можете:

- 📍 Показване на историята на местоположенията
- ⛛ Филтриране на точки
- ✎ Ръчно редактиране / добавяне / изтриване на точки
- ✎ Редактиране на устройства (преименуване, промяна на цвят/форма, преместване в друга сесия)
- ⛶ Определете зоните за ограждане за устройства
- ⚇ Определете сигналите за близост за двойки устройства
- 🖧 Споделете сесия с други потребители на Nextcloud или с публична връзка (само за четене)
- 🔗 Генериране на връзки за обществен дял с незадължителни ограничения (филтри, име на устройството, само последни позиции, опростяване на географски ограничения)
- 🖫 Импортиране / експортиране на сесии във GPX формат (един файл на лог на устройство или един файл на устройство)
- 🗠 Показване на статистически данни за сесиите
- 🔒 [Резарвирайте име на устройството](https://gitlab.com/eneiluj/phonetrack-oc/wikis/userdoc#device-name-reservation) за да сте сигурни, че само оторизиран потребител може да влезе с това име
- 🗓 Превключване на автоматично експортиране на сесия и автоматично почистване (ежедневно/седмично/месечно)
- ◔ Изберете какво да правите, когато се достигне квота за номер на точка (блокиране на регистрация или изтриване на най-старата точка)

Публичната страница и публично филтрираната страница работят като главната страница, с изключение на това, че се показва само една сесия, всичко е само за четене и няма нужда да влизате в системата.

Това приложение е тествано на Nextcloud 17 с Firefox 57+ и Chromium.

Това приложение е съвместимо с тематични цветове и теми за достъпност!

Това приложение е в процес на разработка.

## Инсталирай

Вижте [ AdminDoc ](https://gitlab.com/eneiluj/phonetrack-oc/wikis/admindoc) за подробности за инсталирането.

Проверете [ CHANGELOG ](https://gitlab.com/eneiluj/phonetrack-oc/blob/master/CHANGELOG.md#change-log) файла, за да видите какво има ново и какво предстои в следващото издание.

Проверете [ AUTHORS ](https://gitlab.com/eneiluj/phonetrack-oc/blob/master/AUTHORS.md#authors) файла, за да видите пълния списък с автори.

## Известни проблеми

- PhoneTrack **now works** with Nextcloud group restriction activated. See [admindoc](https://gitlab.com/eneiluj/phonetrack-oc/wikis/admindoc#issue-with-phonetrack-restricted-to-some-groups-in-nextcloud).

Всяка обратна връзка ще бъде оценена.

