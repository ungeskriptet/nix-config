# PhoneTrack додаток для Nextcloud

📱 PhoneTrack це додаток Nextcloud для відстеження і зберігання геолокації мобільних пристроїв.

🗺 отримує інформацію від додатків для мобільних телефонів і динамічно відображає її на карті.

🌍 Допоможіть нам перекласти цей додаток на [PhoneTrack Crowdin](https://crowdin.com/project/phonetrack).

⚒ Перегляньте інші способи допомогти в [інструкціях з контрибуції](https://gitlab.com/eneiluj/phonetrack-oc/blob/master/CONTRIBUTING.md).

Як використовувати PhoneTrack:

- Створіть сесію трекінгу.
- Give the logging link\* to the mobile devices. Choose the [logging method](https://gitlab.com/eneiluj/phonetrack-oc/wikis/userdoc#logging-methods) you prefer.
- Переглядайте місце розташування пристроїв у реальному часі (або ні) у PhoneTrack або діліться нею на загальнодоступних сторінках.

(\*) Don't forget to set the device name in the link (rather than in the logging app settings). Replace "yourname" with the desired device name.
Setting the device name in logging app settings only works with Owntracks, Traccar and OpenGTS.

На головній сторінці PhoneTrack під час перегляду сесії ви можете:

- 📍 Переглядати історію місцезнаходжень
- ⛛ Фільтрувати точки
- ✎ Вручну редагувати/додавати/видаляти точки
- ✎ Редагувати пристрої (перейменувати, змінити колір/форму, перемістити в іншу сесію)
- ⛶ Визначити зони віртуального паркану (geofencing) для пристроїв
- ⚇ Визначати сповіщення про наближення для пар пристроїв
- 🖧 Надати доступ до сесії для інших користувачів Nextcloud або для публічного перегляду (лише для читання)
- 🔗 Створювати посилання для публічного перегляду з обмеженнями (фільтри, назва пристрою, лише останні позиції, спрощені геопаркани)
- 🖫 Імпортувати/експортувати сесії у форматі GPX (потреково для пристрою чи одним файлам)
- 🗠 Переглядати статистику сесії
- 🔒 [Зарезервувати ім'я пристрою](https://gitlab.com/eneiluj/phonetrack-oc/wikis/userdoc#device-name-reservation), щоб переконатися, що тільки авторизований користувач може використовувати це ім'я
- 🗓 Налаштувати автоматичний експорт та автоочищення (щодня/щотижнево/щомісячно)
- ◔ Обирати, що робити при досягненні квоти точок (блокувати подальше збирання чи видаляти найстаріші точки)

Публічна сторінка та публічна сторінка з фільтрами працюють як головна сторінка, за винятком того, що відображається лише одна сесія, все доступне лише для читання, і немає необхідності авторизуватися.

Цей додаток протестований на Nextcloud 17 з Firefox 57+ та Chromium.

Цей додаток сумісний з кольорами тем і темами для людей з особливими потребами!

Цей додаток в стадії розробки.

## Встановлення

Дивіться [AdminDoc](https://gitlab.com/eneiluj/phonetrack-oc/wikis/admindoc) з детальною інформацією про встановлення.

Перевірте [CHANGELOG](https://gitlab.com/eneiluj/phonetrack-oc/blob/master/CHANGELOG.md#change-log), щоб побачити, що нового і що буде в наступному релізі.

Перевірте [AUTHORS](https://gitlab.com/eneiluj/phonetrack-oc/blob/master/AUTHORS.md#authors) щоб побачити повний список авторів.

## Відомі проблеми

- PhoneTrack **now works** with Nextcloud group restriction activated. See [admindoc](https://gitlab.com/eneiluj/phonetrack-oc/wikis/admindoc#issue-with-phonetrack-restricted-to-some-groups-in-nextcloud).

Будемо вдячні за будь-який відгук.

