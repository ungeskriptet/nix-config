OC.L10N.register(
    "phonetrack",
    {
    "Delete" : "Kustuta",
    "Device name" : "Seadme nimi"
},
"nplurals=2; plural=(n != 1);");
