# Authors

* Julien Veyssier <eneiluj@posteo.net> @eneiluj (Developer)
* Roberto Quintiliani @robyquin (Developer)
* Zach DeCook @earboxer (Designer)
* Valdnet @Valdnet (Designer/Tester)
* Jörn Friedrich Dreyer @butonic (Developer)
* CCode @cgcng (Developer)
* Kai Stian Olstad @kaistian (Developer)
* Jason Raveling @webunraveling (Developer)
* :heart: 85 translators on Crowdin
